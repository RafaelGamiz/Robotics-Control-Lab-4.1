RJCrew
Josue Ureña Valencia			IRS | A01738940
César Arellano Arellano			IRS | A00839373
Jose Eduardo Sanchez Martinez		IRS | A01738476
Rafael André Gamiz Salazar		IRS | A00838280

$ colcon build
$ source install/setup.bash
$ ros2 launch roarm_description roarm_gazebo.launch.py

